# Aiuto studioù

PWA installabile con archivio locale e modalità offline.

## Funzioni
- Piani di studio con sessioni distribuite fino alla data d’esame.
- Calendario di lezioni, esami e attività con promemoria.
- Appunti con cartelle, tag, ricerca, allegati e link.
- Flashcard con ripetizione dilazionata e quiz generati dagli appunti tramite Ollama locale.
- Monitoraggio di attività, tempo e ripasso.
- Timer studio/pausa e modalità concentrazione.
- Esportazione/importazione per trasferire dati e condivisione esplicita dei singoli appunti.
- Modalità universitaria facoltativa con profilo ateneo/facoltà/anno, corsi, CFU, appelli, progetti, bibliografia, link ai servizi e dashboard.
- Preferenze di accessibilità e cancellazione dei dati locali.

## Limiti di sincronizzazione e collaborazione
I dati restano nel browser/dispositivo. Per trasferirli usa Esporta dati e poi Importa dati sull’altro dispositivo. La modalità universitaria e il relativo profilo sono facoltativi. I link universitari sono segnalibri e non collegano account né salvano credenziali. Non è incluso un servizio cloud né la collaborazione in tempo reale. La condivisione usa il foglio di condivisione del sistema o crea un file scaricabile.

## Pubblicazione e installazione
Per installare la PWA, pubblica questa cartella su HTTPS. Su Google Play occorre anche un wrapper Android Trusted Web Activity (TWA) e il collegamento Digital Asset Links. Vedi play-store/TWA-PLAY-REQUIREMENTS.md.
