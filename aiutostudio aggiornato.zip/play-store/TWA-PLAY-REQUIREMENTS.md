# Preparazione Google Play — Aiuto studioù

La PWA non può essere caricata direttamente su Google Play. Dopo la pubblicazione del sito PWA su HTTPS, creare un wrapper Android Trusted Web Activity (TWA), collegarlo al dominio con Digital Asset Links e generare un Android App Bundle (.aab) firmato. Google documenta Bubblewrap come strumento per generare/buildare il wrapper TWA.

Prima del build definitivo serviranno:
- URL HTTPS permanente della PWA;
- package ID Android disponibile e scelto dal proprietario (non modificabile in seguito senza creare un'altra app);
- chiave/firma e file Digital Asset Links con l'impronta corretta;
- account Play Console del proprietario verificato;
- identità del titolare verificata, email di supporto e informativa privacy pubblica controllata;
- scheda dati sicurezza, classificazione contenuti, categoria, icona e screenshot richiesti dal Play Console.

Il Play Console richiede un'iscrizione Full distribution con una quota una tantum di 25 USD. Per nuovi account personali, Google richiede un test chiuso con almeno 12 tester iscritti in modo continuativo per 14 giorni prima di richiedere la distribuzione in produzione. Non accettare termini, pagare quote o usare dati di identità senza l'azione del titolare dell'account.
