# Scheda Google Play — Aiuto studioù

**Nome:** Aiuto studioù

**Descrizione breve:** Organizza lo studio universitario: piani, appunti, scadenze e ripasso.

**Descrizione completa:**
Aiuto studioù raccoglie in un unico spazio gli strumenti per organizzare lo studio universitario.

• Crea piani personalizzati e distribuisci le sessioni fino alla data d’esame.
• Attiva facoltativamente la modalità universitaria: profilo ateneo, facoltà e anno; corsi, CFU, prerequisiti, appelli e progressi verso la laurea.
• Organizza progetti di gruppo, ruoli, scadenze, riunioni e bibliografia; salva link rapidi ai servizi del tuo ateneo.
• Visualizza in una dashboard lezioni, appelli, scadenze e attività imminenti.
• Aggiungi lezioni, esami e compiti al calendario e imposta promemoria.
• Organizza gli appunti in cartelle, aggiungi tag, cerca nel testo e collega immagini, PDF, audio e link.
• Crea flashcard, ripassa a intervalli e genera quiz e schede dagli appunti con un modello AI locale.
• Segui attività completate, tempo di studio e argomenti da ripassare.
• Usa il timer con pause e la modalità concentrazione.
• Esporta e importa un archivio per trasferire i contenuti tra dispositivi; condividi solo gli appunti che scegli.
• Regola dimensione del testo, contrasto e animazioni.

I contenuti vengono conservati sul dispositivo. Non è attiva la sincronizzazione automatica né la modifica collaborativa in tempo reale. L’AI testuale richiede Ollama sul dispositivo. La trascrizione audio richiede un servizio Whisper compatibile configurato dall’utente e invia l’audio all’indirizzo scelto, dopo conferma.

**Categoria suggerita:** Istruzione
**Email assistenza:** piumigabriele406@gmail.com
**URL privacy policy:** da pubblicare insieme al sito HTTPS
**Package ID Android:** da scegliere e verificare nel Play Console
**Screenshot e icona store:** da preparare dopo il build Android
**Permessi usati:** microfono per registrare; notifiche, solo se l’utente le attiva.
